import {
  isWritableStore
} from "./chunk-I6GVR4NV.js";

// node_modules/@typhonjs-fvtt/runtime/_dist/svelte/animate/index.js
function animateEvents(fn, store = void 0) {
  if (typeof fn !== "function") {
    throw new TypeError(`'fn' is not a function.`);
  }
  if (store !== void 0 && !isWritableStore(store)) {
    throw new TypeError(`'store' is not a writable store.`);
  }
  let startFired = false;
  let endFired = false;
  return (node, animations, params = {}) => {
    const animationConfig = fn(node, animations, params);
    const existingTick = animationConfig.tick;
    animationConfig.tick = (t, u) => {
      if (existingTick) {
        existingTick(t, u);
      }
      if (!startFired && t === 0) {
        if (store) {
          store.set(true);
        }
        node.dispatchEvent(new CustomEvent("animate:start", { bubbles: true }));
        startFired = true;
        endFired = false;
      }
      if (!endFired && t === 1) {
        if (store) {
          store.set(false);
        }
        node.dispatchEvent(new CustomEvent("animate:end", { bubbles: true }));
        endFired = true;
        startFired = false;
      }
    };
    return animationConfig;
  };
}
async function nextAnimationFrame(cntr = 1) {
  if (!Number.isInteger(cntr) || cntr < 1) {
    throw new TypeError(`nextAnimationFrame error: 'cntr' must be a positive integer greater than 0.`);
  }
  let currentTime = performance.now();
  for (; --cntr >= 0; ) {
    currentTime = await new Promise((resolve) => requestAnimationFrame(resolve));
  }
  return currentTime;
}

export {
  animateEvents,
  nextAnimationFrame
};
//# sourceMappingURL=chunk-77M2F73A.js.map
