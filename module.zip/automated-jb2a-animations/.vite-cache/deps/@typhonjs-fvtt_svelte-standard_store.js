import {
  TJSDialog
} from "./chunk-M7Q5IO73.js";
import "./chunk-77M2F73A.js";
import "./chunk-XAX5UMEN.js";
import {
  localize
} from "./chunk-O4YYAJH7.js";
import {
  ripple,
  rippleFocus
} from "./chunk-JJNTGMUB.js";
import "./chunk-3Q76N6IK.js";
import {
  DynArrayReducer,
  isWritableStore,
  propertyStore,
  subscribeIgnoreFirst
} from "./chunk-I6GVR4NV.js";
import {
  writable
} from "./chunk-5XJTXTW6.js";
import "./chunk-7MS7FSMB.js";
import "./chunk-AFTQYMJX.js";
import "./chunk-6A2TAOKG.js";
import {
  StyleManager,
  debounce,
  isIterable,
  isObject,
  isSvelteComponent,
  klona,
  normalizeString,
  uuidv4
} from "./chunk-ZYVLR2M6.js";
import {
  get_store_value
} from "./chunk-Q23ZHNO4.js";
import {
  __privateAdd,
  __privateGet,
  __privateMethod,
  __privateSet
} from "./chunk-7HFSXBDU.js";

// node_modules/@typhonjs-fvtt/runtime/_dist/color/colord/index.js
var r = { grad: 0.9, turn: 360, rad: 360 / (2 * Math.PI) };
var t = function(r2) {
  return "string" == typeof r2 ? r2.length > 0 : "number" == typeof r2;
};
var n = function(r2, t2, n2) {
  return void 0 === t2 && (t2 = 0), void 0 === n2 && (n2 = Math.pow(10, t2)), Math.round(n2 * r2) / n2 + 0;
};
var o = function(r2, t2, n2) {
  return void 0 === t2 && (t2 = 0), void 0 === n2 && (n2 = 1), r2 > n2 ? n2 : r2 > t2 ? r2 : t2;
};
var e = function(r2) {
  return (r2 = isFinite(r2) ? r2 % 360 : 0) > 0 ? r2 : r2 + 360;
};
var u = function(r2) {
  return { r: o(r2.r, 0, 255), g: o(r2.g, 0, 255), b: o(r2.b, 0, 255), a: o(r2.a) };
};
var a = function(r2, t2) {
  return void 0 === t2 && (t2 = 0), { r: n(r2.r, t2), g: n(r2.g, t2), b: n(r2.b, t2), a: n(r2.a, 3 > t2 ? 3 : t2) };
};
var i = /^#([0-9a-f]{3,8})$/i;
var s = function(r2) {
  var t2 = r2.toString(16);
  return t2.length < 2 ? "0" + t2 : t2;
};
var c = function(r2) {
  var t2 = r2.r, n2 = r2.g, o2 = r2.b, e2 = r2.a, u2 = Math.max(t2, n2, o2), a2 = u2 - Math.min(t2, n2, o2), i2 = a2 ? u2 === t2 ? (n2 - o2) / a2 : u2 === n2 ? 2 + (o2 - t2) / a2 : 4 + (t2 - n2) / a2 : 0;
  return { h: 60 * (i2 < 0 ? i2 + 6 : i2), s: u2 ? a2 / u2 * 100 : 0, v: u2 / 255 * 100, a: e2 };
};
var h = function(r2) {
  var t2 = r2.h, n2 = r2.s, o2 = r2.v, e2 = r2.a;
  t2 = t2 / 360 * 6, n2 /= 100, o2 /= 100;
  var u2 = Math.floor(t2), a2 = o2 * (1 - n2), i2 = o2 * (1 - (t2 - u2) * n2), s2 = o2 * (1 - (1 - t2 + u2) * n2), c2 = u2 % 6;
  return { r: 255 * [o2, i2, a2, a2, s2, o2][c2], g: 255 * [s2, o2, o2, i2, a2, a2][c2], b: 255 * [a2, a2, s2, o2, o2, i2][c2], a: e2 };
};
var d = function(r2) {
  return { h: e(r2.h), s: o(r2.s, 0, 100), l: o(r2.l, 0, 100), a: o(r2.a) };
};
var b = function(r2, t2) {
  return void 0 === t2 && (t2 = 0), { h: n(r2.h, t2), s: n(r2.s, t2), l: n(r2.l, t2), a: n(r2.a, 3 > t2 ? 3 : t2) };
};
var g = function(r2) {
  return h((n2 = (t2 = r2).s, { h: t2.h, s: (n2 *= ((o2 = t2.l) < 50 ? o2 : 100 - o2) / 100) > 0 ? 2 * n2 / (o2 + n2) * 100 : 0, v: o2 + n2, a: t2.a }));
  var t2, n2, o2;
};
var f = function(r2) {
  return { h: (t2 = c(r2)).h, s: (e2 = (200 - (n2 = t2.s)) * (o2 = t2.v) / 100) > 0 && e2 < 200 ? n2 * o2 / 100 / (e2 <= 100 ? e2 : 200 - e2) * 100 : 0, l: e2 / 2, a: t2.a };
  var t2, n2, o2, e2;
};
var v = /^hsla?\(\s*([+-]?\d*\.?\d+)(deg|rad|grad|turn)?\s*,\s*([+-]?\d*\.?\d+)%\s*,\s*([+-]?\d*\.?\d+)%\s*(?:,\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i;
var l = /^hsla?\(\s*([+-]?\d*\.?\d+)(deg|rad|grad|turn)?\s+([+-]?\d*\.?\d+)%\s+([+-]?\d*\.?\d+)%\s*(?:\/\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i;
var p = /^rgba?\(\s*([+-]?\d*\.?\d+)(%)?\s*,\s*([+-]?\d*\.?\d+)(%)?\s*,\s*([+-]?\d*\.?\d+)(%)?\s*(?:,\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i;
var m = /^rgba?\(\s*([+-]?\d*\.?\d+)(%)?\s+([+-]?\d*\.?\d+)(%)?\s+([+-]?\d*\.?\d+)(%)?\s*(?:\/\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i;
var y = { string: [[function(r2) {
  var t2 = i.exec(r2);
  return t2 ? (r2 = t2[1]).length <= 4 ? { r: parseInt(r2[0] + r2[0], 16), g: parseInt(r2[1] + r2[1], 16), b: parseInt(r2[2] + r2[2], 16), a: 4 === r2.length ? n(parseInt(r2[3] + r2[3], 16) / 255, 2) : 1 } : 6 === r2.length || 8 === r2.length ? { r: parseInt(r2.substr(0, 2), 16), g: parseInt(r2.substr(2, 2), 16), b: parseInt(r2.substr(4, 2), 16), a: 8 === r2.length ? n(parseInt(r2.substr(6, 2), 16) / 255, 2) : 1 } : null : null;
}, "hex"], [function(r2) {
  var t2 = p.exec(r2) || m.exec(r2);
  return t2 ? t2[2] !== t2[4] || t2[4] !== t2[6] ? null : u({ r: Number(t2[1]) / (t2[2] ? 100 / 255 : 1), g: Number(t2[3]) / (t2[4] ? 100 / 255 : 1), b: Number(t2[5]) / (t2[6] ? 100 / 255 : 1), a: void 0 === t2[7] ? 1 : Number(t2[7]) / (t2[8] ? 100 : 1) }) : null;
}, "rgb"], [function(t2) {
  var n2 = v.exec(t2) || l.exec(t2);
  if (!n2)
    return null;
  var o2, e2, u2 = d({ h: (o2 = n2[1], e2 = n2[2], void 0 === e2 && (e2 = "deg"), Number(o2) * (r[e2] || 1)), s: Number(n2[3]), l: Number(n2[4]), a: void 0 === n2[5] ? 1 : Number(n2[5]) / (n2[6] ? 100 : 1) });
  return g(u2);
}, "hsl"]], object: [[function(r2) {
  var n2 = r2.r, o2 = r2.g, e2 = r2.b, a2 = r2.a, i2 = void 0 === a2 ? 1 : a2;
  return t(n2) && t(o2) && t(e2) ? u({ r: Number(n2), g: Number(o2), b: Number(e2), a: Number(i2) }) : null;
}, "rgb"], [function(r2) {
  var n2 = r2.h, o2 = r2.s, e2 = r2.l, u2 = r2.a, a2 = void 0 === u2 ? 1 : u2;
  if (!t(n2) || !t(o2) || !t(e2))
    return null;
  var i2 = d({ h: Number(n2), s: Number(o2), l: Number(e2), a: Number(a2) });
  return g(i2);
}, "hsl"], [function(r2) {
  var n2 = r2.h, u2 = r2.s, a2 = r2.v, i2 = r2.a, s2 = void 0 === i2 ? 1 : i2;
  if (!t(n2) || !t(u2) || !t(a2))
    return null;
  var c2 = function(r3) {
    return { h: e(r3.h), s: o(r3.s, 0, 100), v: o(r3.v, 0, 100), a: o(r3.a) };
  }({ h: Number(n2), s: Number(u2), v: Number(a2), a: Number(s2) });
  return h(c2);
}, "hsv"]] };
var N = function(r2, t2) {
  for (var n2 = 0; n2 < t2.length; n2++) {
    var o2 = t2[n2][0](r2);
    if (o2)
      return [o2, t2[n2][1]];
  }
  return [null, void 0];
};
var x = function(r2) {
  return "string" == typeof r2 ? N(r2.trim(), y.string) : "object" == typeof r2 && null !== r2 ? N(r2, y.object) : [null, void 0];
};
var I = function(r2) {
  return x(r2)[1];
};
var M = function(r2, t2) {
  var n2 = f(r2);
  return { h: n2.h, s: o(n2.s + 100 * t2, 0, 100), l: n2.l, a: n2.a };
};
var H = function(r2) {
  return (299 * r2.r + 587 * r2.g + 114 * r2.b) / 1e3 / 255;
};
var $ = function(r2, t2) {
  var n2 = f(r2);
  return { h: n2.h, s: n2.s, l: o(n2.l + 100 * t2, 0, 100), a: n2.a };
};
var j = function() {
  function r2(r3) {
    this.parsed = x(r3)[0], this.rgba = this.parsed || { r: 0, g: 0, b: 0, a: 1 };
  }
  return r2.prototype.isValid = function() {
    return null !== this.parsed;
  }, r2.prototype.brightness = function() {
    return n(H(this.rgba), 2);
  }, r2.prototype.isDark = function() {
    return H(this.rgba) < 0.5;
  }, r2.prototype.isLight = function() {
    return H(this.rgba) >= 0.5;
  }, r2.prototype.toHex = function() {
    return r3 = a(this.rgba), t2 = r3.r, o2 = r3.g, e2 = r3.b, i2 = (u2 = r3.a) < 1 ? s(n(255 * u2)) : "", "#" + s(t2) + s(o2) + s(e2) + i2;
    var r3, t2, o2, e2, u2, i2;
  }, r2.prototype.toRgb = function(r3) {
    return void 0 === r3 && (r3 = 0), a(this.rgba, r3);
  }, r2.prototype.toRgbString = function(r3) {
    return void 0 === r3 && (r3 = 0), function(r4, t2) {
      void 0 === t2 && (t2 = 0);
      var n2 = a(r4, t2), o2 = n2.r, e2 = n2.g, u2 = n2.b, i2 = n2.a;
      return i2 < 1 ? "rgba(".concat(o2, ", ").concat(e2, ", ").concat(u2, ", ").concat(i2, ")") : "rgb(".concat(o2, ", ").concat(e2, ", ").concat(u2, ")");
    }(this.rgba, r3);
  }, r2.prototype.toHsl = function(r3) {
    return void 0 === r3 && (r3 = 0), b(f(this.rgba), r3);
  }, r2.prototype.toHslString = function(r3) {
    return void 0 === r3 && (r3 = 0), function(r4, t2) {
      void 0 === t2 && (t2 = 0);
      var n2 = b(f(r4), t2), o2 = n2.h, e2 = n2.s, u2 = n2.l, a2 = n2.a;
      return a2 < 1 ? "hsla(".concat(o2, ", ").concat(e2, "%, ").concat(u2, "%, ").concat(a2, ")") : "hsl(".concat(o2, ", ").concat(e2, "%, ").concat(u2, "%)");
    }(this.rgba, r3);
  }, r2.prototype.toHsv = function(r3) {
    return void 0 === r3 && (r3 = 0), function(r4, t2) {
      return void 0 === t2 && (t2 = 0), { h: n(r4.h, t2), s: n(r4.s, t2), v: n(r4.v, t2), a: n(r4.a, 3 > t2 ? 3 : t2) };
    }(c(this.rgba), r3);
  }, r2.prototype.invert = function() {
    return w({ r: 255 - (r3 = this.rgba).r, g: 255 - r3.g, b: 255 - r3.b, a: r3.a });
    var r3;
  }, r2.prototype.saturate = function(r3) {
    return void 0 === r3 && (r3 = 0.1), w(M(this.rgba, r3));
  }, r2.prototype.desaturate = function(r3) {
    return void 0 === r3 && (r3 = 0.1), w(M(this.rgba, -r3));
  }, r2.prototype.grayscale = function() {
    return w(M(this.rgba, -1));
  }, r2.prototype.lighten = function(r3) {
    return void 0 === r3 && (r3 = 0.1), w($(this.rgba, r3));
  }, r2.prototype.darken = function(r3) {
    return void 0 === r3 && (r3 = 0.1), w($(this.rgba, -r3));
  }, r2.prototype.rotate = function(r3) {
    return void 0 === r3 && (r3 = 15), this.hue(this.hue() + r3);
  }, r2.prototype.alpha = function(r3) {
    return "number" == typeof r3 ? w({ r: (t2 = this.rgba).r, g: t2.g, b: t2.b, a: r3 }) : n(this.rgba.a, 3);
    var t2;
  }, r2.prototype.hue = function(r3) {
    var t2 = f(this.rgba);
    return "number" == typeof r3 ? w({ h: r3, s: t2.s, l: t2.l, a: t2.a }) : n(t2.h);
  }, r2.prototype.isEqual = function(r3) {
    return this.toHex() === w(r3).toHex();
  }, r2;
}();
var w = function(r2) {
  return r2 instanceof j ? r2 : new j(r2);
};

// node_modules/@typhonjs-fvtt/svelte-standard/_dist/store/index.js
var _data, _subscriptions;
var ObjectEntryStore = class {
  /**
   * @param {object}   data -
   */
  constructor(data = {}) {
    /**
     * @type {object}
     */
    __privateAdd(this, _data, void 0);
    /**
     * Stores the subscribers.
     *
     * @type {(function(object): void)[]}
     */
    __privateAdd(this, _subscriptions, []);
    if (!isObject(data)) {
      throw new TypeError(`'data' is not an object.`);
    }
    __privateSet(this, _data, data);
    if (typeof data.id !== "string") {
      __privateGet(this, _data).id = uuidv4();
    }
    if (!uuidv4.isValid(data.id)) {
      throw new Error(`'data.id' (${data.id}) is not a valid UUIDv4 string.`);
    }
  }
  /**
   * Invoked by ArrayObjectStore to provide custom duplication. Override this static method in your entry store.
   *
   * @param {object}   data - A copy of local data w/ new ID already set.
   *
   * @param {ArrayObjectStore} arrayStore - The source ArrayObjectStore instance.
   */
  static duplicate(data, arrayStore) {
  }
  // eslint-disable-line no-unused-vars
  /**
   * @returns {object}
   * @protected
   */
  get _data() {
    return __privateGet(this, _data);
  }
  // ----------------------------------------------------------------------------------------------------------------
  /**
   * @returns {string}
   */
  get id() {
    return __privateGet(this, _data).id;
  }
  toJSON() {
    return __privateGet(this, _data);
  }
  /**
   * @param {function(object): void} handler - Callback function that is invoked on update / changes.
   *
   * @returns {(function(): void)} Unsubscribe function.
   */
  subscribe(handler) {
    __privateGet(this, _subscriptions).push(handler);
    handler(__privateGet(this, _data));
    return () => {
      const index = __privateGet(this, _subscriptions).findIndex((sub) => sub === handler);
      if (index >= 0) {
        __privateGet(this, _subscriptions).splice(index, 1);
      }
    };
  }
  /**
   * @protected
   */
  _updateSubscribers() {
    const subscriptions = __privateGet(this, _subscriptions);
    const data = __privateGet(this, _data);
    for (let cntr = 0; cntr < subscriptions.length; cntr++) {
      subscriptions[cntr](data);
    }
  }
};
_data = new WeakMap();
_subscriptions = new WeakMap();
var _data2, _dataMap, _dataReducer, _manualUpdate, _StoreClass, _subscriptions2, _updateSubscribersBound, _createStore, createStore_fn, _deleteStore, deleteStore_fn;
var ArrayObjectStore = class {
  /**
   * @param {ArrayObjectStoreParams} params -
   */
  constructor({ StoreClass, defaultData = [], childDebounce = 250, dataReducer = false, manualUpdate = false } = {}) {
    /**
     * Add a new store entry from the given data.
     *
     * @param {object}   entryData -
     *
     * @returns {T} New store entry instance.
     */
    __privateAdd(this, _createStore);
    __privateAdd(this, _deleteStore);
    /** @type {T[]} */
    __privateAdd(this, _data2, []);
    /**
     * @type {Map<string, { store: T, unsubscribe: Function}>}
     */
    __privateAdd(this, _dataMap, /* @__PURE__ */ new Map());
    /**
     * @type {DynArrayReducer<T>}
     */
    __privateAdd(this, _dataReducer, void 0);
    /**
     * @type {boolean}
     */
    __privateAdd(this, _manualUpdate, void 0);
    __privateAdd(this, _StoreClass, void 0);
    /**
     * Stores the subscribers.
     *
     * @type {(function(T[]): void)[]}
     */
    __privateAdd(this, _subscriptions2, []);
    /**
     * @type {Function}
     */
    __privateAdd(this, _updateSubscribersBound, void 0);
    if (!Number.isInteger(childDebounce) || childDebounce < 0 || childDebounce > 1e3) {
      throw new TypeError(`'childDebounce' must be an integer between and including 0 - 1000.`);
    }
    if (typeof manualUpdate !== "boolean") {
      throw new TypeError(`'manualUpdate' is not a boolean.`);
    }
    if (!isWritableStore(StoreClass.prototype)) {
      throw new TypeError(`'StoreClass' is not a writable store constructor.`);
    }
    let hasIDGetter = false;
    for (let o2 = StoreClass.prototype; o2; o2 = Object.getPrototypeOf(o2)) {
      const descriptor = Object.getOwnPropertyDescriptor(o2, "id");
      if (descriptor !== void 0 && descriptor.get !== void 0) {
        hasIDGetter = true;
        break;
      }
    }
    if (!hasIDGetter) {
      throw new TypeError(`'StoreClass' does not have a getter accessor for 'id' property.`);
    }
    if (!Array.isArray(defaultData)) {
      throw new TypeError(`'defaultData' is not an array.`);
    }
    __privateSet(this, _manualUpdate, manualUpdate);
    __privateSet(this, _StoreClass, StoreClass);
    if (dataReducer) {
      __privateSet(this, _dataReducer, new DynArrayReducer({ data: __privateGet(this, _data2) }));
    }
    __privateSet(this, _updateSubscribersBound, childDebounce === 0 ? this.updateSubscribers.bind(this) : debounce((data) => this.updateSubscribers(data), childDebounce));
  }
  /**
   * @returns {ObjectEntryStore}
   */
  static get EntryStore() {
    return ObjectEntryStore;
  }
  /**
   * Provide an iterator for public access to entry stores.
   *
   * @returns {Generator<T | void>}
   * @yields {T|void}
   */
  *[Symbol.iterator]() {
    if (__privateGet(this, _data2).length === 0) {
      return;
    }
    for (const entryStore of __privateGet(this, _data2)) {
      yield entryStore;
    }
  }
  /**
   * @returns {T[]}
   * @protected
   */
  get _data() {
    return __privateGet(this, _data2);
  }
  /**
   * @returns {DynArrayReducer<T>}
   */
  get dataReducer() {
    if (!__privateGet(this, _dataReducer)) {
      throw new Error(
        `'dataReducer' is not initialized; did you forget to specify 'dataReducer' as true in constructor options?`
      );
    }
    return __privateGet(this, _dataReducer);
  }
  /**
   * @returns {number}
   */
  get length() {
    return __privateGet(this, _data2).length;
  }
  /**
   * Removes all child store entries.
   */
  clearEntries() {
    for (const storeEntryData of __privateGet(this, _dataMap).values()) {
      storeEntryData.unsubscribe();
    }
    __privateGet(this, _dataMap).clear();
    __privateGet(this, _data2).length = 0;
    this.updateSubscribers();
  }
  /**
   * Creates a new store from given data.
   *
   * @param {object}   entryData -
   *
   * @returns {T}
   */
  createEntry(entryData = {}) {
    if (!isObject(entryData)) {
      throw new TypeError(`'entryData' is not an object.`);
    }
    if (typeof entryData.id !== "string") {
      entryData.id = uuidv4();
    }
    if (__privateGet(this, _data2).findIndex((entry) => entry.id === entryData.id) >= 0) {
      throw new Error(`'entryData.id' (${entryData.id}) already in this ArrayObjectStore instance.`);
    }
    const store = __privateMethod(this, _createStore, createStore_fn).call(this, entryData);
    this.updateSubscribers();
    return store;
  }
  /**
   * Deletes a given entry store by ID from this world setting array store instance.
   *
   * @param {string}  id - ID of entry to delete.
   *
   * @returns {boolean} Delete operation successful.
   */
  deleteEntry(id) {
    const result = __privateMethod(this, _deleteStore, deleteStore_fn).call(this, id);
    if (result) {
      this.updateSubscribers();
    }
    return result;
  }
  /**
   * Duplicates an entry store by the given ID.
   *
   * @param {string}   id - UUIDv4 string.
   *
   * @returns {*} Instance of StoreClass.
   */
  duplicateEntry(id) {
    var _a, _b;
    if (typeof id !== "string") {
      throw new TypeError(`'id' is not a string.`);
    }
    const storeEntryData = __privateGet(this, _dataMap).get(id);
    if (storeEntryData) {
      const data = klona(storeEntryData.store.toJSON());
      data.id = uuidv4();
      (_b = (_a = __privateGet(this, _StoreClass)) == null ? void 0 : _a.duplicate) == null ? void 0 : _b.call(_a, data, this);
      return this.createEntry(data);
    }
    return void 0;
  }
  /**
   * Find an entry in the backing child store array.
   *
   * @param {function(T): T|void}  predicate - A predicate function
   *
   * @returns {T|void} Found entry in array or undefined.
   */
  findEntry(predicate) {
    return __privateGet(this, _data2).find(predicate);
  }
  /**
   * Finds an entry store instance by 'id' / UUIDv4.
   *
   * @param {string}   id - A UUIDv4 string.
   *
   * @returns {T|void} Entry store instance.
   */
  getEntry(id) {
    const storeEntryData = __privateGet(this, _dataMap).get(id);
    return storeEntryData ? storeEntryData.store : void 0;
  }
  /**
   * Sets the children store data by 'id', adds new entry store instances, or removes entries that are no longer in the
   * update list.
   *
   * @param {T[]}   updateList -
   */
  set(updateList) {
    if (!Array.isArray(updateList)) {
      console.warn(`ArrayObjectStore.set warning: aborting set operation as 'updateList' is not an array.`);
      return;
    }
    const data = __privateGet(this, _data2);
    const dataMap = __privateGet(this, _dataMap);
    const removeIDSet = new Set(dataMap.keys());
    let rebuildIndex = false;
    for (let updateIndex = 0; updateIndex < updateList.length; updateIndex++) {
      const updateData = updateList[updateIndex];
      const id = updateData.id;
      if (typeof id !== "string") {
        throw new Error(`'updateData.id' is not a string.`);
      }
      const localIndex = data.findIndex((entry) => entry.id === id);
      if (localIndex >= 0) {
        const localEntry = data[localIndex];
        localEntry.set(updateData);
        if (localIndex !== updateIndex) {
          data.splice(localIndex, 1);
          if (updateIndex < data.length) {
            data.splice(updateIndex, 0, localEntry);
          } else {
            rebuildIndex = true;
          }
        }
        removeIDSet.delete(id);
      } else {
        __privateMethod(this, _createStore, createStore_fn).call(this, updateData);
      }
    }
    if (rebuildIndex) {
      for (const storeEntryData of dataMap.values()) {
        storeEntryData.unsubscribe();
      }
      data.length = 0;
      dataMap.clear();
      for (const updateData of updateList) {
        __privateMethod(this, _createStore, createStore_fn).call(this, updateData);
      }
    } else {
      for (const id of removeIDSet) {
        __privateMethod(this, _deleteStore, deleteStore_fn).call(this, id);
      }
    }
    this.updateSubscribers();
  }
  toJSON() {
    return __privateGet(this, _data2);
  }
  // -------------------------------------------------------------------------------------------------------------------
  /**
   * @param {function(T[]): void} handler - Callback function that is invoked on update / changes.
   *
   * @returns {(function(): void)} Unsubscribe function.
   */
  subscribe(handler) {
    __privateGet(this, _subscriptions2).push(handler);
    handler(__privateGet(this, _data2));
    return () => {
      const index = __privateGet(this, _subscriptions2).findIndex((sub) => sub === handler);
      if (index >= 0) {
        __privateGet(this, _subscriptions2).splice(index, 1);
      }
    };
  }
  /**
   * Updates subscribers.
   *
   * @param {ArrayObjectUpdateData}  [update] -
   */
  updateSubscribers(update) {
    const updateGate = typeof update === "boolean" ? update : !__privateGet(this, _manualUpdate);
    if (updateGate) {
      const subscriptions = __privateGet(this, _subscriptions2);
      const data = __privateGet(this, _data2);
      for (let cntr = 0; cntr < subscriptions.length; cntr++) {
        subscriptions[cntr](data);
      }
    }
    if (__privateGet(this, _dataReducer)) {
      __privateGet(this, _dataReducer).index.update(true);
    }
  }
};
_data2 = new WeakMap();
_dataMap = new WeakMap();
_dataReducer = new WeakMap();
_manualUpdate = new WeakMap();
_StoreClass = new WeakMap();
_subscriptions2 = new WeakMap();
_updateSubscribersBound = new WeakMap();
_createStore = new WeakSet();
createStore_fn = function(entryData) {
  const store = new (__privateGet(this, _StoreClass))(entryData, this);
  if (!uuidv4.isValid(store.id)) {
    throw new Error(`'store.id' (${store.id}) is not a UUIDv4 compliant string.`);
  }
  const unsubscribe = subscribeIgnoreFirst(store, __privateGet(this, _updateSubscribersBound));
  __privateGet(this, _data2).push(store);
  __privateGet(this, _dataMap).set(entryData.id, { store, unsubscribe });
  return store;
};
_deleteStore = new WeakSet();
deleteStore_fn = function(id) {
  if (typeof id !== "string") {
    throw new TypeError(`'id' is not a string.`);
  }
  const storeEntryData = __privateGet(this, _dataMap).get(id);
  if (storeEntryData) {
    storeEntryData.unsubscribe();
    __privateGet(this, _dataMap).delete(id);
    const index = __privateGet(this, _data2).findIndex((entry) => entry.id === id);
    if (index >= 0) {
      __privateGet(this, _data2).splice(index, 1);
    }
    return true;
  }
  return false;
};
var _crudDispatch, _extraData;
var CrudArrayObjectStore = class extends ArrayObjectStore {
  /**
   * @param {object}                  [opts] - Optional parameters.
   *
   * @param {CrudDispatch}            [opts.crudDispatch] -
   *
   * @param {object}                  [opts.extraData] -
   *
   * @param {ArrayObjectStoreParams}  [opts.rest] - Rest of ArrayObjectStore parameters.
   */
  constructor({ crudDispatch, extraData, ...rest }) {
    super({
      manualUpdate: typeof crudDispatch === "function",
      ...rest
    });
    /** @type {CrudDispatch} */
    __privateAdd(this, _crudDispatch, void 0);
    /** @type {object} */
    __privateAdd(this, _extraData, void 0);
    if (crudDispatch !== void 0 && typeof crudDispatch !== "function") {
      throw new TypeError(`'crudDispatch' is not a function.`);
    }
    if (extraData !== void 0 && !isObject(extraData)) {
      throw new TypeError(`'extraData' is not an object.`);
    }
    __privateSet(this, _crudDispatch, crudDispatch);
    __privateSet(this, _extraData, extraData ?? {});
  }
  /**
   * Removes all child store entries.
   */
  clearEntries() {
    super.clearEntries();
    if (__privateGet(this, _crudDispatch)) {
      __privateGet(this, _crudDispatch).call(this, { action: "clear", ...__privateGet(this, _extraData) });
    }
  }
  /**
   * Creates a new store from given data.
   *
   * @param {object}   entryData -
   *
   * @returns {T}
   */
  createEntry(entryData = {}) {
    const store = super.createEntry(entryData);
    if (store && __privateGet(this, _crudDispatch)) {
      __privateGet(this, _crudDispatch).call(this, {
        action: "create",
        ...__privateGet(this, _extraData),
        id: store.id,
        data: store.toJSON()
      });
    }
    return store;
  }
  /**
   * Deletes a given entry store by ID from this world setting array store instance.
   *
   * @param {string}  id - ID of entry to delete.
   *
   * @returns {boolean} Delete operation successful.
   */
  deleteEntry(id) {
    const result = super.deleteEntry(id);
    if (result && __privateGet(this, _crudDispatch)) {
      __privateGet(this, _crudDispatch).call(this, { action: "delete", ...__privateGet(this, _extraData), id });
    }
    return result;
  }
  /**
   * Updates subscribers, but provides special handling when WorldSettingArrayStore has an `crudDispatch` function
   * attached. When the update is an object with a valid UUIDv4 string as the id property the `crudDispatch`
   * function is invoked with  along with the data payload
   *
   * @param {ArrayObjectUpdateData} [update] -
   */
  updateSubscribers(update) {
    if (__privateGet(this, _crudDispatch) && isObject(update) && uuidv4.isValid(update.id)) {
      const result = __privateGet(this, _crudDispatch).call(this, {
        action: "update",
        ...__privateGet(this, _extraData),
        id: update.id,
        data: update
        // TODO: Consider using klona to clone data.
      });
      super.updateSubscribers(typeof result === "boolean" ? result : update);
    } else {
      super.updateSubscribers(update);
    }
  }
};
_crudDispatch = new WeakMap();
_extraData = new WeakMap();
function createFilterQuery(properties, { caseSensitive = false, store } = {}) {
  let keyword = "";
  let regex;
  if (store !== void 0 && !isWritableStore(store)) {
    throw new TypeError(`createFilterQuery error: 'store' is not a writable store.`);
  }
  const storeKeyword = store ? store : writable(keyword);
  if (store) {
    const current = get_store_value(store);
    if (typeof current === "string") {
      keyword = normalizeString(current);
      regex = new RegExp(RegExp.escape(keyword), caseSensitive ? "" : "i");
    } else {
      store.set(keyword);
    }
  }
  function filterQuery(data) {
    if (keyword === "" || !regex) {
      return true;
    }
    if (isIterable(properties)) {
      for (const property of properties) {
        if (regex.test(normalizeString(data == null ? void 0 : data[property]))) {
          return true;
        }
      }
      return false;
    } else {
      return regex.test(normalizeString(data == null ? void 0 : data[properties]));
    }
  }
  filterQuery.subscribe = (handler) => {
    return storeKeyword.subscribe(handler);
  };
  filterQuery.set = (value) => {
    if (typeof value === "string") {
      keyword = normalizeString(value);
      regex = new RegExp(RegExp.escape(keyword), caseSensitive ? "" : "i");
      storeKeyword.set(keyword);
    }
  };
  return filterQuery;
}
var _sections, _settings, _showSettings, _showSettingsSet, _stores, _destroy, destroy_fn, _parseSettings, parseSettings_fn, _reloadConfirm, reloadConfirm_fn;
var UIControl = class {
  /**
   * @param {TJSGameSettings}   settings -
   */
  constructor(settings) {
    /**
     * Destroy callback. Checks for any `requiresReload` parameter in each setting comparing against initial value
     * when `settings` is created and current value. If there is a difference then show a modal dialog asking the user
     * if they want to reload for those settings to take effect.
     *
     * @param {TJSSettingsUIData}   settings - The UI data object initiated w/ `create`.
     */
    __privateAdd(this, _destroy);
    /**
     * @param {TJSSettingsCreateOptions} [options] - Optional parameters.
     *
     * @returns {TJSSettingsUIData} Parsed UI settings data.
     */
    __privateAdd(this, _parseSettings);
    __privateAdd(this, _reloadConfirm);
    /** @type {TJSSettingsCustomSection[]} */
    __privateAdd(this, _sections, []);
    /** @type {TJSGameSettings} */
    __privateAdd(this, _settings, void 0);
    /** @type {boolean} */
    __privateAdd(this, _showSettings, false);
    /** @type {Function} */
    __privateAdd(this, _showSettingsSet, void 0);
    /** @type {{showSettings: import('svelte/store').Readable<boolean>}} */
    __privateAdd(this, _stores, void 0);
    __privateSet(this, _settings, settings);
    const showSettings = writable(__privateGet(this, _showSettings));
    __privateSet(this, _showSettingsSet, showSettings.set);
    __privateSet(this, _stores, {
      showSettings: { subscribe: showSettings.subscribe }
    });
    Object.freeze(__privateGet(this, _stores));
  }
  /**
   * @returns {boolean} Current `showSettings` state.
   */
  get showSettings() {
    return __privateGet(this, _showSettings);
  }
  /**
   * @returns {{showSettings: import('svelte/store').Readable<boolean>}} Returns the managed stores.
   */
  get stores() {
    return __privateGet(this, _stores);
  }
  /**
   * Sets current `showSettings` state.
   *
   * @param {boolean}  showSettings - New `showSettings` state.
   */
  set showSettings(showSettings) {
    __privateSet(this, _showSettings, showSettings);
    __privateGet(this, _showSettingsSet).call(this, __privateGet(this, _showSettings));
  }
  /**
   * Adds a custom section / folder defined by the provided TJSSettingsCustomSection options object.
   *
   * @param {TJSSettingsCustomSection} options - The configuration object for the custom section.
   */
  addSection(options) {
    if (!isObject(options)) {
      throw new TypeError(`'options' is not an object.`);
    }
    if (!isSvelteComponent(options.class)) {
      throw new TypeError(`'options.class' is not a Svelte component.`);
    }
    if (options.props !== void 0 && !isObject(options.props)) {
      throw new TypeError(`'options.props' is not an object.`);
    }
    if (options.folder !== void 0) {
      const folder = options.folder;
      if (typeof folder !== "string" && !isObject(folder)) {
        throw new TypeError(`'options.folder' is not a string or object.`);
      }
      if (isObject(folder)) {
        if (typeof folder.label !== "string") {
          throw new TypeError(`'options.folder.label' is not a string.`);
        }
        if (folder.summaryEnd !== void 0) {
          if (!isObject(folder.summaryEnd)) {
            throw new TypeError(`'options.folder.summaryEnd' is not an object.`);
          }
          if (!isSvelteComponent(folder.summaryEnd.class)) {
            throw new TypeError(`'options.folder.summaryEnd.class' is not a Svelte component.`);
          }
          if (folder.summaryEnd.props !== void 0 && !isObject(folder.summaryEnd.props)) {
            throw new TypeError(`'options.folder.summaryEnd.props' is not an object.`);
          }
        }
        if (folder.styles !== void 0 && !isObject(folder.styles)) {
          throw new TypeError(`'options.folder.styles' is not an object.`);
        }
      }
    }
    if (options.styles !== void 0 && !isObject(options.styles)) {
      throw new TypeError(`'options.styles' is not an object.`);
    }
    __privateGet(this, _sections).push(options);
  }
  /**
   * Creates the UISettingsData object by parsing stored settings in
   *
   * @param {TJSSettingsCreateOptions} [options] - Optional parameters.
   *
   * @returns {TJSSettingsUIData} Parsed UI settings data.
   */
  create(options) {
    const settings = __privateMethod(this, _parseSettings, parseSettings_fn).call(this, options);
    const destroy = () => __privateMethod(this, _destroy, destroy_fn).call(this, settings);
    return {
      ...settings,
      destroy
    };
  }
  /**
   * Convenience method to swap `showSettings`.
   *
   * @returns {boolean} New `showSettings` state.
   */
  swapShowSettings() {
    __privateSet(this, _showSettings, !__privateGet(this, _showSettings));
    __privateGet(this, _showSettingsSet).call(this, __privateGet(this, _showSettings));
    return __privateGet(this, _showSettings);
  }
};
_sections = new WeakMap();
_settings = new WeakMap();
_showSettings = new WeakMap();
_showSettingsSet = new WeakMap();
_stores = new WeakMap();
_destroy = new WeakSet();
destroy_fn = function(settings) {
  let requiresClientReload = false;
  let requiresWorldReload = false;
  if (Array.isArray(settings.topLevel)) {
    for (const setting of settings.topLevel) {
      const current = globalThis.game.settings.get(setting.namespace, setting.key);
      if (current === setting.initialValue) {
        continue;
      }
      requiresClientReload || (requiresClientReload = setting.scope === "client" && setting.requiresReload);
      requiresWorldReload || (requiresWorldReload = setting.scope === "world" && setting.requiresReload);
    }
  }
  if (Array.isArray(settings.folders)) {
    for (const folder of settings.folders) {
      if (Array.isArray(folder.settings)) {
        for (const setting of folder.settings) {
          const current = globalThis.game.settings.get(setting.namespace, setting.key);
          if (current === setting.initialValue) {
            continue;
          }
          requiresClientReload || (requiresClientReload = setting.scope === "client" && setting.requiresReload);
          requiresWorldReload || (requiresWorldReload = setting.scope === "world" && setting.requiresReload);
        }
      }
    }
  }
  if (requiresClientReload || requiresWorldReload) {
    __privateMethod(this, _reloadConfirm, reloadConfirm_fn).call(this, { world: requiresWorldReload });
  }
  __privateSet(this, _showSettings, false);
  __privateGet(this, _showSettingsSet).call(this, __privateGet(this, _showSettings));
};
_parseSettings = new WeakSet();
parseSettings_fn = function({ efx = "ripple", storage } = {}) {
  const namespace = __privateGet(this, _settings).namespace;
  if (storage && typeof namespace !== "string") {
    console.warn(
      `TJSGameSettings warning: 'options.storage' defined, but 'namespace' not defined in TJSGameSettings.`
    );
  }
  const hasStorage = storage && typeof namespace === "string";
  const uiSettings = [];
  const canConfigure = globalThis.game.user.can("SETTINGS_MODIFY");
  for (const setting of __privateGet(this, _settings)) {
    if (!setting.config || !canConfigure && setting.scope !== "client") {
      continue;
    }
    let options;
    if (typeof setting.choices === "object") {
      options = Object.entries(setting.choices).map((entry) => ({ value: entry[0], label: localize(entry[1]) }));
    }
    let range;
    if (typeof setting.range === "object") {
      range = {};
      if (typeof setting.range.min !== "number") {
        throw new TypeError(`Setting 'range.min' is not a number.`);
      }
      if (typeof setting.range.max !== "number") {
        throw new TypeError(`Setting 'range.max' is not a number.`);
      }
      if (setting.range.step !== void 0 && typeof setting.range.step !== "number") {
        throw new TypeError(`Setting 'range.step' is not a number.`);
      }
      range.min = setting.range.min;
      range.max = setting.range.max;
      range.step = setting.range.step ? setting.range.step : 1;
    }
    const type = setting.type instanceof Function ? setting.type.name : "String";
    let filePicker;
    if (type === "String") {
      filePicker = setting.filePicker === true ? "any" : setting.filePicker;
    }
    let buttonData;
    if (filePicker) {
      buttonData = {
        icon: "fas fa-file-import fa-fw",
        efx: efx === "ripple" ? ripple() : void 0,
        title: "FILES.BrowseTooltip",
        styles: { "margin-left": "0.25em" }
      };
    }
    const store = __privateGet(this, _settings).getStore(setting.key);
    let selectData;
    let componentType = "text";
    if (setting.type === Boolean) {
      componentType = "checkbox";
    } else if (options !== void 0) {
      componentType = "select";
      selectData = {
        store,
        efx: efx === "ripple" ? rippleFocus() : void 0,
        type: componentType,
        options
      };
    } else if (setting.type === Number) {
      componentType = typeof setting.range === "object" ? "range" : "number";
    }
    let inputData;
    if (componentType === "text" || componentType === "number") {
      inputData = {
        store,
        efx: efx === "ripple" ? rippleFocus() : void 0,
        type: componentType
      };
    }
    uiSettings.push({
      id: `${setting.namespace}.${setting.key}`,
      namespace: setting.namespace,
      folder: setting.folder,
      key: setting.key,
      name: localize(setting.name),
      hint: localize(setting.hint),
      type,
      componentType,
      filePicker,
      range,
      store,
      initialValue: globalThis.game.settings.get(setting.namespace, setting.key),
      scope: setting.scope,
      requiresReload: typeof setting.requiresReload === "boolean" ? setting.requiresReload : false,
      buttonData,
      inputData,
      selectData
    });
  }
  const storeScrollbar = hasStorage ? storage.getStore(`${namespace}-settings-scrollbar`) : writable(0);
  const topLevel = [];
  const folderData = {};
  for (const setting of uiSettings) {
    if (typeof setting.folder === "string") {
      const folderName = localize(setting.folder);
      if (!Array.isArray(folderData[folderName])) {
        folderData[folderName] = [];
      }
      folderData[folderName].push(setting);
    } else {
      topLevel.push(setting);
    }
  }
  const folders = Object.entries(folderData).map((entry) => {
    return {
      label: entry[0],
      store: hasStorage ? storage.getStore(`${namespace}-settings-folder-${entry[0]}`) : void 0,
      settings: entry[1]
    };
  });
  const sections = [];
  for (const section of __privateGet(this, _sections)) {
    const parsedSection = {
      class: section.class,
      props: section.props,
      styles: section.styles
    };
    if (typeof section.folder === "string") {
      const label = localize(section.folder);
      parsedSection.folder = {
        label,
        store: hasStorage ? storage.getStore(`${namespace}-settings-folder-${label}`) : void 0
      };
    } else if (isObject(section.folder)) {
      const label = localize(section.folder.label);
      parsedSection.folder = {
        label,
        store: hasStorage ? storage.getStore(`${namespace}-settings-folder-${label}`) : void 0,
        summaryEnd: section.folder.summaryEnd,
        styles: section.folder.styles
      };
    }
    sections.push(parsedSection);
  }
  return {
    storeScrollbar,
    topLevel,
    folders,
    sections
  };
};
_reloadConfirm = new WeakSet();
reloadConfirm_fn = async function({ world = false } = {}) {
  let title = localize("SETTINGS.ReloadPromptTitle");
  let label = localize("SETTINGS.ReloadPromptBody");
  title = title !== "SETTINGS.ReloadPromptTitle" ? title : "Reload Application?";
  label = label !== "SETTINGS.ReloadPromptBody" ? label : "Some of the changed settings require a reload of the application to take effect. Would you like to reload now?";
  const reload = await TJSDialog.confirm({
    modal: true,
    draggable: false,
    title,
    content: `<p>${label}</p>`
  });
  if (!reload) {
    return;
  }
  if (world && globalThis.game.user.isGM) {
    globalThis.game.socket.emit("reload");
  }
  window.location.reload();
};
var _namespace, _settings2, _stores2, _uiControl, _createStore2, createStore_fn2, _getStore, getStore_fn;
var _TJSGameSettings = class {
  /**
   * Creates the TJSGameSettings instance.
   *
   * @param {string}   namespace - The namespace for all settings.
   */
  constructor(namespace) {
    /**
     * Gets a store from the `stores` Map or creates a new store for the key.
     *
     * @param {string}   key - Key to lookup in stores map.
     *
     * @param {string}   [initialValue] - An initial value to set to new stores.
     *
     * @returns {import('svelte/store').Writable} The store for the given key.
     */
    __privateAdd(this, _getStore);
    /** @type {string} */
    __privateAdd(this, _namespace, void 0);
    /** @type {GameSettingData[]} */
    __privateAdd(this, _settings2, []);
    /**
     * @type {Map<string, import('svelte/store').Writable>}
     */
    __privateAdd(this, _stores2, /* @__PURE__ */ new Map());
    /** @type {UIControl} */
    __privateAdd(this, _uiControl, void 0);
    if (typeof namespace !== "string") {
      throw new TypeError(`'namespace' is not a string.`);
    }
    __privateSet(this, _namespace, namespace);
    __privateSet(this, _uiControl, new UIControl(this));
  }
  /**
   * Provides an iterator / generator to return stored settings data.
   *
   * @returns {Generator<GameSettingData, void, *>}
   */
  *[Symbol.iterator]() {
    for (const setting of __privateGet(this, _settings2)) {
      yield setting;
    }
  }
  /**
   * @returns {string} Returns namespace set in constructor.
   */
  get namespace() {
    return __privateGet(this, _namespace);
  }
  /**
   * @returns {UIControl}
   */
  get uiControl() {
    return __privateGet(this, _uiControl);
  }
  /**
   * Returns a readable Game Settings store for the associated key.
   *
   * @param {string}   key - Game setting key.
   *
   * @returns {import('svelte/store').Readable|undefined} The associated store for the given game setting key.
   */
  getReadableStore(key) {
    if (!__privateGet(this, _stores2).has(key)) {
      console.warn(`TJSGameSettings - getReadableStore: '${key}' is not a registered setting.`);
      return;
    }
    const store = __privateMethod(this, _getStore, getStore_fn).call(this, key);
    return { subscribe: store.subscribe };
  }
  /**
   * Returns a writable Game Settings store for the associated key.
   *
   * @param {string}   key - Game setting key.
   *
   * @returns {import('svelte/store').Writable|undefined} The associated store for the given game setting key.
   */
  getStore(key) {
    return this.getWritableStore(key);
  }
  /**
   * Returns a writable Game Settings store for the associated key.
   *
   * @param {string}   key - Game setting key.
   *
   * @returns {import('svelte/store').Writable|undefined} The associated store for the given game setting key.
   */
  getWritableStore(key) {
    if (!__privateGet(this, _stores2).has(key)) {
      console.warn(`TJSGameSettings - getWritableStore: '${key}' is not a registered setting.`);
      return;
    }
    return __privateMethod(this, _getStore, getStore_fn).call(this, key);
  }
  /**
   * Registers a setting with TJSGameSettings and Foundry core.
   *
   * Note: The specific store subscription handler assigned to the passed in store or store created for the setting
   * internally is returned from this function. In some cases when setting up custom stores particularly of object
   * types with several child property stores (`propertyStore`) it is necessary to only update the setting store and
   * not all subscribers to the custom store as the `propertyStore` instances are also subscribers to the custom store.
   *
   * This allows the custom store in the `set` implementation to mainly only trigger the TJSGameSettings subscriber
   * handler on updates and not all the connected `propertyStore` instances.
   *
   * @param {GameSetting} setting - A GameSetting instance to set to Foundry game settings.
   *
   * @param {boolean}     coreConfig - When false this overrides the `setting.options.config` parameter when
   *                                   registering the setting with Foundry. This allows the settings to be displayed
   *                                   in the app itself, but removed from the standard Foundry configuration location.
   *
   * @returns {Function} The specific store subscription handler assigned to the passed in store.
   */
  register(setting, coreConfig = true) {
    if (!isObject(setting)) {
      throw new TypeError(`TJSGameSettings - register: setting is not an object.`);
    }
    if (!isObject(setting.options)) {
      throw new TypeError(`TJSGameSettings - register: 'setting.options' attribute is not an object.`);
    }
    if (typeof coreConfig !== "boolean") {
      throw new TypeError(`TJSGameSettings - register: 'coreConfig' is not an boolean.`);
    }
    if (setting.store !== void 0 && !isWritableStore(setting.store)) {
      throw new TypeError(
        `TJSGameSettings - register: 'setting.store' attribute is not a writable store.`
      );
    }
    const namespace = setting.namespace;
    const key = setting.key;
    const folder = setting.folder;
    const foundryConfig = coreConfig ? setting.options.config : false;
    if (typeof namespace !== "string") {
      throw new TypeError(`TJSGameSettings - register: 'namespace' attribute is not a string.`);
    }
    if (typeof key !== "string") {
      throw new TypeError(`TJSGameSettings - register: 'key' attribute is not a string.`);
    }
    if (folder !== void 0 && typeof folder !== "string") {
      throw new TypeError(`TJSGameSettings - register: 'folder' attribute is not a string.`);
    }
    const store = setting.store;
    const options = setting.options;
    const onchangeFunctions = [];
    let gateSet = false;
    onchangeFunctions.push((value) => {
      const callbackStore = __privateMethod(this, _getStore, getStore_fn).call(this, key);
      if (callbackStore && !gateSet) {
        gateSet = true;
        callbackStore.set(value);
        gateSet = false;
      }
    });
    if (isIterable(options == null ? void 0 : options.onChange)) {
      for (const entry of options.onChange) {
        if (typeof entry === "function") {
          onchangeFunctions.push(entry);
        }
      }
    } else if (typeof options.onChange === "function") {
      onchangeFunctions.push(options.onChange);
    }
    const onChange = (value) => {
      for (const entry of onchangeFunctions) {
        entry(value);
      }
    };
    globalThis.game.settings.register(namespace, key, { ...options, config: foundryConfig, onChange });
    const targetStore = store ? store : __privateMethod(this, _getStore, getStore_fn).call(this, key, globalThis.game.settings.get(namespace, key));
    if (store) {
      __privateGet(this, _stores2).set(key, targetStore);
      store.set(globalThis.game.settings.get(namespace, key));
    }
    const storeHandler = async (value) => {
      if (!gateSet && globalThis.game.settings.get(namespace, key) !== value) {
        gateSet = true;
        await globalThis.game.settings.set(namespace, key, value);
      }
      gateSet = false;
    };
    subscribeIgnoreFirst(targetStore, storeHandler);
    __privateGet(this, _settings2).push({
      namespace,
      key,
      folder,
      ...options
    });
    return storeHandler;
  }
  /**
   * Registers multiple settings.
   *
   * Please refer to the note in {@link TJSGameSettings.register} about the returned object of store subscriber handler
   * functions.
   *
   * @param {Iterable<GameSetting>} settings - An iterable list of game setting configurations to register.
   *
   * @param {boolean}     coreConfig - When false this overrides the `setting.options.config` parameter when
   *                                   registering the setting with Foundry. This allows the settings to be displayed
   *                                   in the app itself, but removed from the standard Foundry configuration location.
   *
   * @returns {Object<string, Function>} An object containing all TJSGameSetting store subscriber handlers for each
   * setting `key` added.
   */
  registerAll(settings, coreConfig) {
    const storeHandlers = {};
    if (!isIterable(settings)) {
      throw new TypeError(`TJSGameSettings - registerAll: settings is not iterable.`);
    }
    for (const entry of settings) {
      if (!isObject(entry)) {
        throw new TypeError(`TJSGameSettings - registerAll: entry in settings is not an object.`);
      }
      if (typeof entry.namespace !== "string") {
        throw new TypeError(`TJSGameSettings - registerAll: entry in settings missing 'namespace' attribute.`);
      }
      if (typeof entry.key !== "string") {
        throw new TypeError(`TJSGameSettings - registerAll: entry in settings missing 'key' attribute.`);
      }
      if (!isObject(entry.options)) {
        throw new TypeError(`TJSGameSettings - registerAll: entry in settings missing 'options' attribute.`);
      }
      storeHandlers[entry.key] = this.register(entry, coreConfig);
    }
    return storeHandlers;
  }
};
var TJSGameSettings = _TJSGameSettings;
_namespace = new WeakMap();
_settings2 = new WeakMap();
_stores2 = new WeakMap();
_uiControl = new WeakMap();
_createStore2 = new WeakSet();
createStore_fn2 = function(initialValue) {
  return writable(initialValue);
};
_getStore = new WeakSet();
getStore_fn = function(key, initialValue) {
  var _a;
  let store = __privateGet(this, _stores2).get(key);
  if (store === void 0) {
    store = __privateMethod(_a = _TJSGameSettings, _createStore2, createStore_fn2).call(_a, initialValue);
    __privateGet(this, _stores2).set(key, store);
  }
  return store;
};
/**
 * Creates a new writable for the given key.
 *
 * @param {*}  initialValue - An initial value to set to new stores.
 *
 * @returns {import('svelte/store').Writable} The new writable.
 */
__privateAdd(TJSGameSettings, _createStore2);
var _currentData, _gameSettings, _subscriptions3, _lastKey, _updateSubscribers, updateSubscribers_fn;
var TJSLiveGameSettings = class {
  /**
   * Creates a live binding against the setting stores. All settings are configured by default, but can also be
   * filtered by setting key with inclusive / exclusive Sets.
   *
   * @param {TJSGameSettings}   gameSettings - A game settings instance to subscribe to...
   *
   * @param {object}            [options] - TJSLiveGameSettings options.
   *
   * @param {Set<string>}       [options.include] - A Set of setting keys to include from subscribing.
   *
   * @param {Set<string>}       [options.exclude] - A Set of setting keys to exclude from subscribing.
   */
  constructor(gameSettings, { include, exclude } = {}) {
    /**
     * Updates subscribers.
     *
     * @param {string} key - The key that was updated.
     */
    __privateAdd(this, _updateSubscribers);
    /**
     * Stores the current parsed game setting data.
     *
     * @type {{}}
     */
    __privateAdd(this, _currentData, {});
    /**
     * Map of all game settings stores and unsubscribe functions currently subscribed.
     *
     * @type {Map<string, { unsubscribe: Function, store: import('svelte/store').Writable }>}
     */
    __privateAdd(this, _gameSettings, /* @__PURE__ */ new Map());
    /**
     * Stores readable subscribers of this instance.
     *
     * Note: When using from JS a second argument is the key that was updated.
     * From Svelte: Use 'lastKey' accessor to retrieve the last updated key.
     *
     * @type {((liveSettings: TJSLiveGameSettings, key: string) => void)[]}
     */
    __privateAdd(this, _subscriptions3, []);
    /**
     * Stores the last updated key.
     *
     * @type {string}
     */
    __privateAdd(this, _lastKey, void 0);
    if (!(gameSettings instanceof TJSGameSettings)) {
      throw new TypeError(`'gameSettings' is not a TJSGameSettings instance.`);
    }
    if (include !== void 0 && !(include instanceof Set)) {
      throw new TypeError(`'options.include' is not a Set.`);
    }
    if (exclude !== void 0 && !(exclude instanceof Set)) {
      throw new TypeError(`'options.exclude' is not a Set.`);
    }
    for (const setting of gameSettings) {
      const key = setting.key;
      if (include !== void 0 && !include.has(key)) {
        continue;
      }
      if (exclude !== void 0 && exclude.has(key)) {
        continue;
      }
      if (typeof this[key] === "function" || key === "lastKey") {
        console.warn(`TJSLiveGameSettings warning: key (${key}) shadows a function. Skipping key.`);
      }
      const store = gameSettings.getStore(key);
      __privateGet(this, _gameSettings).set(key, {
        store,
        unsubscribe: store.subscribe((data) => {
          if (__privateGet(this, _currentData) !== void 0) {
            __privateGet(this, _currentData)[key] = data;
          }
          __privateSet(this, _lastKey, key);
          this._update(key);
          __privateMethod(this, _updateSubscribers, updateSubscribers_fn).call(this, key);
        })
      });
      Object.defineProperty(this, key, {
        get: () => {
          if (__privateGet(this, _currentData) === void 0) {
            throw new Error(`This instance of TJSLiveGameSettings has been destroyed.`);
          } else {
            return __privateGet(this, _currentData)[key];
          }
        },
        set: (data) => {
          if (__privateGet(this, _currentData) === void 0) {
            throw new Error(`This instance of TJSLiveGameSettings has been destroyed.`);
          } else {
            __privateGet(this, _gameSettings).get(key).store.set(data);
          }
        }
      });
    }
    Object.seal(this);
  }
  /**
   * @returns {string} Last updated setting key.
   */
  get lastKey() {
    return __privateGet(this, _lastKey);
  }
  // ----------------------------------------------------------------------------------------------------------------
  /**
   * Destroys this instance of TJSLiveGameSettings and unsubscribes from all game setting stores.
   */
  destroy() {
    for (const data of __privateGet(this, _gameSettings)) {
      if (typeof data.unsubscribe === "function") {
        data.unsubscribe();
      }
    }
    __privateGet(this, _gameSettings).clear();
    __privateSet(this, _currentData, void 0);
  }
  /**
   * Returns an iterator / generator of all setting entries.
   *
   * @returns {Generator<[string, *], void, *>}
   */
  *entries() {
    if (__privateGet(this, _currentData) === void 0) {
      throw new Error(`This instance of TJSLiveGameSettings has been destroyed.`);
    }
    for (const key in __privateGet(this, _currentData)) {
      yield [key, __privateGet(this, _currentData)[key]];
    }
  }
  /**
   * Returns an iterator / generator of all setting keys.
   *
   * @returns {Generator<string, void, *>}
   */
  *keys() {
    if (__privateGet(this, _currentData) === void 0) {
      throw new Error(`This instance of TJSLiveGameSettings has been destroyed.`);
    }
    for (const key in __privateGet(this, _currentData)) {
      yield key;
    }
  }
  /**
   * Returns a string / JSON stringify of the current setting data.
   *
   * @returns {string} Tracked setting data.
   */
  toString() {
    if (__privateGet(this, _currentData) === void 0) {
      throw new Error(`This instance of TJSLiveGameSettings has been destroyed.`);
    }
    return JSON.stringify(__privateGet(this, _currentData));
  }
  /**
   * Override to respond to setting update.
   *
   * @param {string} key - The setting / local key that updated.
   *
   * @protected
   */
  _update(key) {
  }
  // eslint-disable-line no-unused-vars
  /**
   * Returns an iterator / generator of all values.
   *
   * @returns {Generator<*, void, *>}
   */
  *values() {
    if (__privateGet(this, _currentData) === void 0) {
      throw new Error(`This instance of TJSLiveGameSettings has been destroyed.`);
    }
    for (const key in __privateGet(this, _currentData)) {
      yield __privateGet(this, _currentData)[key];
    }
  }
  // Readable store implementation ----------------------------------------------------------------------------------
  /**
   * @param {(liveSettings: TJSLiveGameSettings, key: string) => void} handler - Callback function that is invoked on
   *                                                                             update / changes.
   *
   * @returns {(function(): void)} Unsubscribe function.
   */
  subscribe(handler) {
    __privateGet(this, _subscriptions3).push(handler);
    handler(this, void 0);
    return () => {
      const index = __privateGet(this, _subscriptions3).findIndex((sub) => sub === handler);
      if (index >= 0) {
        __privateGet(this, _subscriptions3).splice(index, 1);
      }
    };
  }
};
_currentData = new WeakMap();
_gameSettings = new WeakMap();
_subscriptions3 = new WeakMap();
_lastKey = new WeakMap();
_updateSubscribers = new WeakSet();
updateSubscribers_fn = function(key) {
  const subscriptions = __privateGet(this, _subscriptions3);
  for (let cntr = 0; cntr < subscriptions.length; cntr++) {
    subscriptions[cntr](this, key);
  }
};
var _components, _defaultThemeData, _initialThemeData, _settingsStoreHandler, _data3, _vars, _subscriptions4, _stores3, _opts, _initialize, initialize_fn, _selectDefaultData, selectDefaultData_fn, _validateThemeData, validateThemeData_fn, _updateSubscribers2, updateSubscribers_fn2;
var TJSThemeStore = class {
  /**
   * @param {object} options - Options
   *
   * @param {string} options.namespace - The world setting scope.
   *
   * @param {string} options.key - The world setting key.
   *
   * @param {TJSGameSettings} options.gameSettings - An associated TJSGameSettings instance.
   *
   * @param {StyleManager} options.styleManager - An associated StyleManager instance to manipulate CSS variables.
   *
   * @param {object[]} options.data - Data defining CSS theme variables.
   *
   */
  constructor(options) {
    __privateAdd(this, _initialize);
    __privateAdd(this, _selectDefaultData);
    /**
     * Validates the given theme data object ensuring that all parameters are found and are correct HSVA values.
     *
     * @param {object}   themeData -
     *
     * @returns {boolean} Validation status.
     */
    __privateAdd(this, _validateThemeData);
    // ------------
    /**
     * Updates all subscribers
     */
    __privateAdd(this, _updateSubscribers2);
    /** @type {object[]} */
    __privateAdd(this, _components, void 0);
    __privateAdd(this, _defaultThemeData, void 0);
    __privateAdd(this, _initialThemeData, void 0);
    __privateAdd(this, _settingsStoreHandler, void 0);
    __privateAdd(this, _data3, {});
    /**
     * Stores all of the CSS variable keys.
     *
     * @type {string[]}
     */
    __privateAdd(this, _vars, void 0);
    /**
     * Stores the subscribers.
     *
     * @type {(function(data): void)[]}
     */
    __privateAdd(this, _subscriptions4, []);
    /**
     * @type {Object<String, import('svelte/store').Writable<string|null>>}
     */
    __privateAdd(this, _stores3, {});
    __privateAdd(this, _opts, void 0);
    if (!isObject(options)) {
      throw new TypeError(`'options' is not an object.`);
    }
    if (typeof options.namespace !== "string") {
      throw new TypeError(`'namespace' is not a string.`);
    }
    if (typeof options.key !== "string") {
      throw new TypeError(`'key' is not a string.`);
    }
    if (!(options.gameSettings instanceof TJSGameSettings)) {
      throw new TypeError(`'gameSettings' is not an instance of TJSGameSettings.`);
    }
    if (!(options.styleManager instanceof StyleManager)) {
      throw new TypeError(`'styleManager' is not an instance of StyleManager.`);
    }
    if (!isIterable(options.data)) {
      throw new TypeError(`'data' is not an iterable list. `);
    }
    __privateSet(this, _opts, Object.assign({}, options));
    __privateMethod(this, _initialize, initialize_fn).call(this);
  }
  /**
   * @returns {Object<String, import('svelte/store').Writable<string|null>>}
   */
  get stores() {
    return __privateGet(this, _stores3);
  }
  /**
   * Sets the theme store with new data.
   *
   * @param {object}   theme -
   *
   * @returns {TJSThemeStore}
   */
  set(theme) {
    if (!__privateMethod(this, _validateThemeData, validateThemeData_fn).call(this, theme)) {
      theme = Object.assign({}, __privateGet(this, _initialThemeData));
    }
    for (const key of __privateGet(this, _vars)) {
      const keyData = theme[key];
      __privateGet(this, _data3)[key] = keyData;
      __privateGet(this, _opts).styleManager.setProperty(key, keyData);
    }
    __privateMethod(this, _updateSubscribers2, updateSubscribers_fn2).call(this);
    return this;
  }
  /**
   * @param {function(data): void} handler - Callback function that is invoked on update / changes.
   * Receives copy of the theme data.
   *
   * @returns {(function(data): void)} Unsubscribe function.
   */
  subscribe(handler) {
    __privateGet(this, _subscriptions4).push(handler);
    handler(Object.assign({}, __privateGet(this, _data3)));
    return () => {
      const index = __privateGet(this, _subscriptions4).findIndex((sub) => sub === handler);
      if (index >= 0) {
        __privateGet(this, _subscriptions4).splice(index, 1);
      }
    };
  }
};
_components = new WeakMap();
_defaultThemeData = new WeakMap();
_initialThemeData = new WeakMap();
_settingsStoreHandler = new WeakMap();
_data3 = new WeakMap();
_vars = new WeakMap();
_subscriptions4 = new WeakMap();
_stores3 = new WeakMap();
_opts = new WeakMap();
_initialize = new WeakSet();
initialize_fn = function() {
  __privateSet(this, _components, []);
  __privateSet(this, _vars, []);
  __privateSet(this, _defaultThemeData, __privateMethod(this, _selectDefaultData, selectDefaultData_fn).call(this));
  __privateSet(this, _initialThemeData, Object.assign({}, __privateGet(this, _defaultThemeData)));
  for (const entry of __privateGet(this, _opts).data) {
    if (typeof entry.var === "string") {
      const key = entry.var;
      __privateGet(this, _vars).push(key);
      __privateGet(this, _stores3)[key] = propertyStore(this, key);
      __privateGet(this, _components).push(Object.assign({}, entry, { store: __privateGet(this, _stores3)[key] }));
    } else {
      __privateGet(this, _components).push(Object.assign({}, entry));
    }
  }
  __privateGet(this, _stores3).components = writable(__privateGet(this, _components));
  __privateSet(this, _settingsStoreHandler, __privateGet(this, _opts).gameSettings.register({
    namespace: __privateGet(this, _opts).namespace,
    key: __privateGet(this, _opts).key,
    store: this,
    options: {
      scope: "world",
      config: false,
      default: Object.assign({}, __privateGet(this, _defaultThemeData)),
      type: Object
    }
  }));
  __privateSet(this, _initialThemeData, game.settings.get(__privateGet(this, _opts).namespace, __privateGet(this, _opts).key));
  if (!__privateMethod(this, _validateThemeData, validateThemeData_fn).call(this, __privateGet(this, _initialThemeData))) {
    console.warn(
      `TinyMCE Everywhere! (mce-everywhere) warning: Initial theme data invalid. Setting to system default.`
    );
    __privateSet(this, _initialThemeData, Object.assign({}, __privateGet(this, _defaultThemeData)));
    this.set(Object.assign({}, __privateGet(this, _initialThemeData)), true);
  }
};
_selectDefaultData = new WeakSet();
selectDefaultData_fn = function() {
  return {
    "--mce-everywhere-toolbar-background": "hsla(0, 0%, 0%, 0.1)",
    "--mce-everywhere-toolbar-button-background-hover": "hsl(60, 35%, 91%)",
    "--mce-everywhere-toolbar-disabled-font-color": "hsla(212, 29%, 19%, 0.5)",
    "--mce-everywhere-toolbar-font-color": "hsl(50, 14%, 9%)"
  };
};
_validateThemeData = new WeakSet();
validateThemeData_fn = function(themeData) {
  if (typeof themeData !== "object" || themeData === null) {
    console.warn(
      `TinyMCE Eveywhere (mce-everywhere) warning: 'theme' data is not an object resetting to initial data.`
    );
    return false;
  }
  for (const key of __privateGet(this, _vars)) {
    const data = themeData[key];
    if (I(data) !== "hsl") {
      console.warn(`TinyMCE Eveywhere (mce-everywhere) warning: data for property '${key}' is not a HSL color string. Resetting to initial data.`);
      return false;
    }
  }
  return true;
};
_updateSubscribers2 = new WeakSet();
updateSubscribers_fn2 = function() {
  const data = Object.assign({}, __privateGet(this, _data3));
  if (__privateGet(this, _subscriptions4).length > 0) {
    for (let cntr = 0; cntr < __privateGet(this, _subscriptions4).length; cntr++) {
      __privateGet(this, _subscriptions4)[cntr](data);
    }
  }
};
var _key, _namespace2;
var WorldSettingArrayStore = class extends CrudArrayObjectStore {
  /**
   *
   * @param {object}            [opts] - Optional parameters.
   *
   * @param {TJSGameSettings}   [opts.gameSettings] - An instance of TJSGameSettings.
   *
   * @param {string}            [opts.namespace] - Game setting 'namespace' field.
   *
   * @param {string}            [opts.key] - Game setting 'key' field.
   *
   * @param {CrudArrayObjectStoreParams} [opts.rest] - Rest of CrudArrayObjectStore parameters.
   */
  constructor({ gameSettings, namespace, key, ...rest }) {
    super({
      ...rest,
      extraData: { namespace, key }
    });
    /** @type {string} */
    __privateAdd(this, _key, void 0);
    /** @type {string} */
    __privateAdd(this, _namespace2, void 0);
    if (typeof key !== "string") {
      throw new TypeError(`'key' is not a string.`);
    }
    if (typeof namespace !== "string") {
      throw new TypeError(`'namespace' is not a string.`);
    }
    __privateSet(this, _namespace2, namespace);
    __privateSet(this, _key, key);
    if (gameSettings) {
      gameSettings.register({
        namespace,
        key,
        store: this,
        options: {
          scope: "world",
          config: false,
          default: Array.isArray(rest.defaultData) ? rest.defaultData : [],
          type: Array
        }
      });
    }
  }
  /**
   * @returns {string}
   */
  get key() {
    return __privateGet(this, _key);
  }
  /**
   * @returns {string}
   */
  get namespace() {
    return __privateGet(this, _namespace2);
  }
};
_key = new WeakMap();
_namespace2 = new WeakMap();
function storeCallback(store, setCallback) {
  if (!isWritableStore(store)) {
    throw new TypeError(`'store' is not a writable store.`);
  }
  if (typeof setCallback !== "function") {
    throw new TypeError(`'setCallback' is not a function.`);
  }
  return {
    set: (value) => {
      store.set(value);
      setCallback(store, value);
    },
    subscribe: store.subscribe,
    update: typeof store.update === "function" ? store.update : void 0
  };
}
export {
  ArrayObjectStore,
  CrudArrayObjectStore,
  ObjectEntryStore,
  TJSGameSettings,
  TJSLiveGameSettings,
  TJSThemeStore,
  WorldSettingArrayStore,
  createFilterQuery,
  storeCallback
};
//# sourceMappingURL=@typhonjs-fvtt_svelte-standard_store.js.map
