import {
  animateEvents,
  nextAnimationFrame
} from "./chunk-77M2F73A.js";
import "./chunk-I6GVR4NV.js";
import "./chunk-5XJTXTW6.js";
import "./chunk-ZYVLR2M6.js";
import "./chunk-Q23ZHNO4.js";
import "./chunk-7HFSXBDU.js";
export {
  animateEvents,
  nextAnimationFrame
};
//# sourceMappingURL=@typhonjs-fvtt_runtime_svelte_animate.js.map
