<script>
    export let title;
</script>

<div class="aa-SectionHeader">
    <div class="flexcol">
        <label for="">{title}</label>
    </div>
</div>

<style lang="scss">
    .aa-SectionHeader {
        border-bottom: 2px solid rgba(181, 69, 52, 0.35);
        margin-bottom: -5px;
        margin-right: 5%;
        margin-left: 5%;
        label {
            align-self: center;
            font-family: "Modesto Condensed", "Palatino Linotype", serif;
            font-size: 23px;
            font-weight: bold;
            text-align: center;
            margin-right: 6%;
            margin-left: 6%;
            color: black;
            padding-top: 2px;
        }
    }
</style>
