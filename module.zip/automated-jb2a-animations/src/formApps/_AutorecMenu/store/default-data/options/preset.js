export function preset(presetType) {
    return {
        
    }
}