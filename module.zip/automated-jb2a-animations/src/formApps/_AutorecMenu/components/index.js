export { default as AutorecAppShell } from "./AutorecAppShell.svelte";
