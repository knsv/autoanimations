import { TJSSessionStorage  } from "@typhonjs-fvtt/runtime/svelte/store";

export const aaSessionStorage = new TJSSessionStorage ();
