---
name: "[SYSTEM REQUEST] - TYPE FULL SYSTEM NAME HERE"
about: Requests for Compatibility with a new game System
title: "[SYSTEM REQUEST] - TYPE FULL SYSTEM NAME HERE"
labels: ''
assignees: ''

---

**NOTE**: Adding new system support is NOT a priority for me. The best way to add support is to issue a Pull Request to add it in yourself.
