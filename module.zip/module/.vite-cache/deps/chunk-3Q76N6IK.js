import {
  isUpdatableStore,
  isWritableStore
} from "./chunk-I6GVR4NV.js";
import {
  cubicOut
} from "./chunk-AFTQYMJX.js";
import {
  debounce,
  hasSetter,
  isIterable,
  isObject,
  styleParsePixels
} from "./chunk-ZYVLR2M6.js";
import {
  __privateAdd,
  __privateGet,
  __privateMethod,
  __privateSet
} from "./chunk-7HFSXBDU.js";

// node_modules/@typhonjs-fvtt/runtime/_dist/svelte/action/index.js
function alwaysBlur(node) {
  function blurNode() {
    setTimeout(() => {
      if (document.activeElement === node) {
        node.blur();
      }
    }, 0);
  }
  node.addEventListener("pointerup", blurNode);
  return {
    destroy: () => node.removeEventListener("pointerup", blurNode)
  };
}
function resizeObserver(node, target) {
  ResizeObserverManager.add(node, target);
  return {
    update: (newTarget) => {
      ResizeObserverManager.remove(node, target);
      target = newTarget;
      ResizeObserverManager.add(node, target);
    },
    destroy: () => {
      ResizeObserverManager.remove(node, target);
    }
  };
}
resizeObserver.updateCache = function(el) {
  if (!(el instanceof HTMLElement)) {
    throw new TypeError(`resizeObserverUpdate error: 'el' is not an HTMLElement.`);
  }
  const subscribers = s_MAP.get(el);
  if (Array.isArray(subscribers)) {
    const computed = globalThis.getComputedStyle(el);
    const borderBottom = styleParsePixels(el.style.borderBottom) ?? styleParsePixels(computed.borderBottom) ?? 0;
    const borderLeft = styleParsePixels(el.style.borderLeft) ?? styleParsePixels(computed.borderLeft) ?? 0;
    const borderRight = styleParsePixels(el.style.borderRight) ?? styleParsePixels(computed.borderRight) ?? 0;
    const borderTop = styleParsePixels(el.style.borderTop) ?? styleParsePixels(computed.borderTop) ?? 0;
    const paddingBottom = styleParsePixels(el.style.paddingBottom) ?? styleParsePixels(computed.paddingBottom) ?? 0;
    const paddingLeft = styleParsePixels(el.style.paddingLeft) ?? styleParsePixels(computed.paddingLeft) ?? 0;
    const paddingRight = styleParsePixels(el.style.paddingRight) ?? styleParsePixels(computed.paddingRight) ?? 0;
    const paddingTop = styleParsePixels(el.style.paddingTop) ?? styleParsePixels(computed.paddingTop) ?? 0;
    const additionalWidth = borderLeft + borderRight + paddingLeft + paddingRight;
    const additionalHeight = borderTop + borderBottom + paddingTop + paddingBottom;
    for (const subscriber of subscribers) {
      subscriber.styles.additionalWidth = additionalWidth;
      subscriber.styles.additionalHeight = additionalHeight;
      s_UPDATE_SUBSCRIBER(subscriber, subscriber.contentWidth, subscriber.contentHeight);
    }
  }
};
var s_MAP = /* @__PURE__ */ new Map();
var ResizeObserverManager = class {
  /**
   * Add an HTMLElement and ResizeObserverTarget instance for monitoring. Create cached style attributes for the
   * given element include border & padding dimensions for offset width / height calculations.
   *
   * @param {HTMLElement}    el - The element to observe.
   *
   * @param {ResizeObserverTarget} target - A target that contains one of several mechanisms for updating resize data.
   */
  static add(el, target) {
    const updateType = s_GET_UPDATE_TYPE(target);
    if (updateType === 0) {
      throw new Error(`'target' does not match supported ResizeObserverManager update mechanisms.`);
    }
    const computed = globalThis.getComputedStyle(el);
    const borderBottom = styleParsePixels(el.style.borderBottom) ?? styleParsePixels(computed.borderBottom) ?? 0;
    const borderLeft = styleParsePixels(el.style.borderLeft) ?? styleParsePixels(computed.borderLeft) ?? 0;
    const borderRight = styleParsePixels(el.style.borderRight) ?? styleParsePixels(computed.borderRight) ?? 0;
    const borderTop = styleParsePixels(el.style.borderTop) ?? styleParsePixels(computed.borderTop) ?? 0;
    const paddingBottom = styleParsePixels(el.style.paddingBottom) ?? styleParsePixels(computed.paddingBottom) ?? 0;
    const paddingLeft = styleParsePixels(el.style.paddingLeft) ?? styleParsePixels(computed.paddingLeft) ?? 0;
    const paddingRight = styleParsePixels(el.style.paddingRight) ?? styleParsePixels(computed.paddingRight) ?? 0;
    const paddingTop = styleParsePixels(el.style.paddingTop) ?? styleParsePixels(computed.paddingTop) ?? 0;
    const data = {
      updateType,
      target,
      // Stores most recent contentRect.width and contentRect.height values from ResizeObserver.
      contentWidth: 0,
      contentHeight: 0,
      // Convenience data for total border & padding for offset width & height calculations.
      styles: {
        additionalWidth: borderLeft + borderRight + paddingLeft + paddingRight,
        additionalHeight: borderTop + borderBottom + paddingTop + paddingBottom
      }
    };
    if (s_MAP.has(el)) {
      const subscribers = s_MAP.get(el);
      subscribers.push(data);
    } else {
      s_MAP.set(el, [data]);
    }
    s_RESIZE_OBSERVER.observe(el);
  }
  /**
   * Removes all targets from monitoring when just an element is provided otherwise removes a specific target
   * from the monitoring map. If no more targets remain then the element is removed from monitoring.
   *
   * @param {HTMLElement}          el - Element to remove from monitoring.
   *
   * @param {ResizeObserverTarget} [target] - A specific target to remove from monitoring.
   */
  static remove(el, target = void 0) {
    const subscribers = s_MAP.get(el);
    if (Array.isArray(subscribers)) {
      const index = subscribers.findIndex((entry) => entry.target === target);
      if (index >= 0) {
        s_UPDATE_SUBSCRIBER(subscribers[index], void 0, void 0);
        subscribers.splice(index, 1);
      }
      if (subscribers.length === 0) {
        s_MAP.delete(el);
        s_RESIZE_OBSERVER.unobserve(el);
      }
    }
  }
};
var s_UPDATE_TYPES = {
  none: 0,
  attribute: 1,
  function: 2,
  resizeObserved: 3,
  setContentBounds: 4,
  setDimension: 5,
  storeObject: 6,
  storesObject: 7
};
var s_RESIZE_OBSERVER = new ResizeObserver((entries) => {
  for (const entry of entries) {
    const subscribers = s_MAP.get(entry == null ? void 0 : entry.target);
    if (Array.isArray(subscribers)) {
      const contentWidth = entry.contentRect.width;
      const contentHeight = entry.contentRect.height;
      for (const subscriber of subscribers) {
        s_UPDATE_SUBSCRIBER(subscriber, contentWidth, contentHeight);
      }
    }
  }
});
function s_GET_UPDATE_TYPE(target) {
  if ((target == null ? void 0 : target.resizeObserved) instanceof Function) {
    return s_UPDATE_TYPES.resizeObserved;
  }
  if ((target == null ? void 0 : target.setDimension) instanceof Function) {
    return s_UPDATE_TYPES.setDimension;
  }
  if ((target == null ? void 0 : target.setContentBounds) instanceof Function) {
    return s_UPDATE_TYPES.setContentBounds;
  }
  const targetType = typeof target;
  if (targetType !== null && (targetType === "object" || targetType === "function")) {
    if (isUpdatableStore(target.resizeObserved)) {
      return s_UPDATE_TYPES.storeObject;
    }
    const stores = target == null ? void 0 : target.stores;
    if (isObject(stores) || typeof stores === "function") {
      if (isUpdatableStore(stores.resizeObserved)) {
        return s_UPDATE_TYPES.storesObject;
      }
    }
  }
  if (targetType !== null && targetType === "object") {
    return s_UPDATE_TYPES.attribute;
  }
  if (targetType === "function") {
    return s_UPDATE_TYPES.function;
  }
  return s_UPDATE_TYPES.none;
}
function s_UPDATE_SUBSCRIBER(subscriber, contentWidth, contentHeight) {
  var _a, _b, _c;
  const styles = subscriber.styles;
  subscriber.contentWidth = contentWidth;
  subscriber.contentHeight = contentHeight;
  const offsetWidth = Number.isFinite(contentWidth) ? contentWidth + styles.additionalWidth : void 0;
  const offsetHeight = Number.isFinite(contentHeight) ? contentHeight + styles.additionalHeight : void 0;
  const target = subscriber.target;
  switch (subscriber.updateType) {
    case s_UPDATE_TYPES.attribute:
      target.contentWidth = contentWidth;
      target.contentHeight = contentHeight;
      target.offsetWidth = offsetWidth;
      target.offsetHeight = offsetHeight;
      break;
    case s_UPDATE_TYPES.function:
      target == null ? void 0 : target(offsetWidth, offsetHeight, contentWidth, contentHeight);
      break;
    case s_UPDATE_TYPES.resizeObserved:
      (_a = target.resizeObserved) == null ? void 0 : _a.call(target, offsetWidth, offsetHeight, contentWidth, contentHeight);
      break;
    case s_UPDATE_TYPES.setContentBounds:
      (_b = target.setContentBounds) == null ? void 0 : _b.call(target, contentWidth, contentHeight);
      break;
    case s_UPDATE_TYPES.setDimension:
      (_c = target.setDimension) == null ? void 0 : _c.call(target, offsetWidth, offsetHeight);
      break;
    case s_UPDATE_TYPES.storeObject:
      target.resizeObserved.update((object) => {
        object.contentHeight = contentHeight;
        object.contentWidth = contentWidth;
        object.offsetHeight = offsetHeight;
        object.offsetWidth = offsetWidth;
        return object;
      });
      break;
    case s_UPDATE_TYPES.storesObject:
      target.stores.resizeObserved.update((object) => {
        object.contentHeight = contentHeight;
        object.contentWidth = contentWidth;
        object.offsetHeight = offsetHeight;
        object.offsetWidth = offsetWidth;
        return object;
      });
      break;
  }
}
function applyScrolltop(element, store) {
  if (!isWritableStore(store)) {
    throw new TypeError(`applyScrolltop error: 'store' must be a writable Svelte store.`);
  }
  function storeUpdate(value) {
    if (!Number.isFinite(value)) {
      return;
    }
    setTimeout(() => element.scrollTop = value, 0);
  }
  let unsubscribe = store.subscribe(storeUpdate);
  const resizeControl = resizeObserver(element, debounce(() => {
    if (element.isConnected) {
      store.set(element.scrollTop);
    }
  }, 500));
  function onScroll(event) {
    store.set(event.target.scrollTop);
  }
  const debounceFn = debounce((e) => onScroll(e), 500);
  element.addEventListener("scroll", debounceFn);
  return {
    update: (newStore) => {
      unsubscribe();
      store = newStore;
      if (!isWritableStore(store)) {
        throw new TypeError(`applyScrolltop.update error: 'store' must be a writable Svelte store.`);
      }
      unsubscribe = store.subscribe(storeUpdate);
    },
    destroy: () => {
      element.removeEventListener("scroll", debounceFn);
      unsubscribe();
      resizeControl.destroy();
    }
  };
}
function autoBlur(node) {
  function onBlur() {
    document.body.removeEventListener("pointerdown", onPointerDown);
  }
  function onFocus() {
    document.body.addEventListener("pointerdown", onPointerDown);
  }
  function onPointerDown(event) {
    if (event.target === node || node.contains(event.target)) {
      return;
    }
    if (document.activeElement === node) {
      node.blur();
    }
  }
  node.addEventListener("blur", onBlur);
  node.addEventListener("focus", onFocus);
  return {
    destroy: () => {
      document.body.removeEventListener("pointerdown", onPointerDown);
      node.removeEventListener("blur", onBlur);
      node.removeEventListener("focus", onFocus);
    }
  };
}
function isFocused(node, storeFocused) {
  let localFocused = false;
  function setFocused(current) {
    localFocused = current;
    if (isWritableStore(storeFocused)) {
      storeFocused.set(localFocused);
    }
  }
  function onFocus() {
    setFocused(true);
  }
  function onBlur() {
    setFocused(false);
  }
  function activateListeners() {
    node.addEventListener("focus", onFocus);
    node.addEventListener("blur", onBlur);
  }
  function removeListeners() {
    node.removeEventListener("focus", onFocus);
    node.removeEventListener("blur", onBlur);
  }
  activateListeners();
  return {
    update: (newStoreFocused) => {
      storeFocused = newStoreFocused;
      setFocused(localFocused);
    },
    destroy: () => removeListeners()
  };
}
function keyforward(node, keyStore) {
  if (typeof (keyStore == null ? void 0 : keyStore.keydown) !== "function" || typeof keyStore.keyup !== "function") {
    throw new TypeError(`'keyStore' doesn't have required 'keydown' or 'keyup' methods.`);
  }
  function onKeydown(event) {
    keyStore.keydown(event);
  }
  function onKeyup(event) {
    keyStore.keyup(event);
  }
  function activateListeners() {
    node.addEventListener("keydown", onKeydown);
    node.addEventListener("keyup", onKeyup);
  }
  function removeListeners() {
    node.removeEventListener("keydown", onKeydown);
    node.removeEventListener("keyup", onKeyup);
  }
  activateListeners();
  return {
    update: (newKeyStore) => {
      keyStore = newKeyStore;
      if (typeof (keyStore == null ? void 0 : keyStore.keydown) !== "function" || typeof keyStore.keyup !== "function") {
        throw new TypeError(`'newKeyStore' doesn't have required 'keydown' or 'keyup' methods.`);
      }
    },
    destroy: () => removeListeners()
  };
}
function applyStyles(node, properties) {
  function setProperties() {
    if (typeof properties !== "object") {
      return;
    }
    for (const prop of Object.keys(properties)) {
      node.style.setProperty(`${prop}`, properties[prop]);
    }
  }
  setProperties();
  return {
    update(newProperties) {
      properties = newProperties;
      setProperties();
    }
  };
}
function applyPosition(node, position) {
  if (hasSetter(position, "parent")) {
    position.parent = node;
  }
  return {
    update: (newPosition) => {
      if (newPosition === position && newPosition.parent === position.parent) {
        return;
      }
      if (hasSetter(position)) {
        position.parent = void 0;
      }
      position = newPosition;
      if (hasSetter(position, "parent")) {
        position.parent = node;
      }
    },
    destroy: () => {
      if (hasSetter(position, "parent")) {
        position.parent = void 0;
      }
    }
  };
}
function draggable(node, {
  position,
  active = true,
  button = 0,
  storeDragging = void 0,
  ease = false,
  easeOptions = { duration: 0.1, ease: cubicOut },
  hasTargetClassList,
  ignoreTargetClassList
}) {
  if (hasTargetClassList !== void 0 && !isIterable(hasTargetClassList)) {
    throw new TypeError(`'hasTargetClassList' is not iterable.`);
  }
  if (ignoreTargetClassList !== void 0 && !isIterable(ignoreTargetClassList)) {
    throw new TypeError(`'ignoreTargetClassList' is not iterable.`);
  }
  let initialPosition = null;
  let initialDragPoint = {};
  let dragging = false;
  let quickTo = position.animate.quickTo(["top", "left"], easeOptions);
  const handlers = {
    dragDown: ["pointerdown", (e) => onDragPointerDown(e), false],
    dragMove: ["pointermove", (e) => onDragPointerChange(e), false],
    dragUp: ["pointerup", (e) => onDragPointerUp(e), false]
  };
  function activateListeners() {
    node.addEventListener(...handlers.dragDown);
    node.classList.add("draggable");
  }
  function removeListeners() {
    if (typeof (storeDragging == null ? void 0 : storeDragging.set) === "function") {
      storeDragging.set(false);
    }
    node.removeEventListener(...handlers.dragDown);
    node.removeEventListener(...handlers.dragMove);
    node.removeEventListener(...handlers.dragUp);
    node.classList.remove("draggable");
  }
  if (active) {
    activateListeners();
  }
  function onDragPointerDown(event) {
    if (event.button !== button || !event.isPrimary) {
      return;
    }
    if (!position.enabled) {
      return;
    }
    if (ignoreTargetClassList !== void 0 && event.target instanceof HTMLElement) {
      for (const targetClass of ignoreTargetClassList) {
        if (event.target.classList.contains(targetClass)) {
          return;
        }
      }
    }
    if (hasTargetClassList !== void 0 && event.target instanceof HTMLElement) {
      let foundTarget = false;
      for (const targetClass of hasTargetClassList) {
        if (event.target.classList.contains(targetClass)) {
          foundTarget = true;
          break;
        }
      }
      if (!foundTarget) {
        return;
      }
    }
    event.preventDefault();
    dragging = false;
    initialPosition = position.get();
    initialDragPoint = { x: event.clientX, y: event.clientY };
    node.addEventListener(...handlers.dragMove);
    node.addEventListener(...handlers.dragUp);
    node.setPointerCapture(event.pointerId);
  }
  function onDragPointerChange(event) {
    if ((event.buttons & 1) === 0) {
      onDragPointerUp(event);
      return;
    }
    if (event.button !== -1 || !event.isPrimary) {
      return;
    }
    event.preventDefault();
    if (!dragging && typeof (storeDragging == null ? void 0 : storeDragging.set) === "function") {
      dragging = true;
      storeDragging.set(true);
    }
    const newLeft = initialPosition.left + (event.clientX - initialDragPoint.x);
    const newTop = initialPosition.top + (event.clientY - initialDragPoint.y);
    if (ease) {
      quickTo(newTop, newLeft);
    } else {
      s_POSITION_DATA.left = newLeft;
      s_POSITION_DATA.top = newTop;
      position.set(s_POSITION_DATA);
    }
  }
  function onDragPointerUp(event) {
    event.preventDefault();
    dragging = false;
    if (typeof (storeDragging == null ? void 0 : storeDragging.set) === "function") {
      storeDragging.set(false);
    }
    node.removeEventListener(...handlers.dragMove);
    node.removeEventListener(...handlers.dragUp);
  }
  return {
    // The default of active being true won't automatically add listeners twice.
    update: (options) => {
      if (typeof options.active === "boolean") {
        active = options.active;
        if (active) {
          activateListeners();
        } else {
          removeListeners();
        }
      }
      if (typeof options.button === "number") {
        button = options.button;
      }
      if (options.position !== void 0 && options.position !== position) {
        position = options.position;
        quickTo = position.animate.quickTo(["top", "left"], easeOptions);
      }
      if (typeof options.ease === "boolean") {
        ease = options.ease;
      }
      if (isObject(options.easeOptions)) {
        easeOptions = options.easeOptions;
        quickTo.options(easeOptions);
      }
      if (options.hasTargetClassList !== void 0) {
        if (!isIterable(options.hasTargetClassList)) {
          throw new TypeError(`'hasTargetClassList' is not iterable.`);
        } else {
          hasTargetClassList = options.hasTargetClassList;
        }
      }
      if (options.ignoreTargetClassList !== void 0) {
        if (!isIterable(options.ignoreTargetClassList)) {
          throw new TypeError(`'ignoreTargetClassList' is not iterable.`);
        } else {
          ignoreTargetClassList = options.ignoreTargetClassList;
        }
      }
    },
    destroy: () => removeListeners()
  };
}
var _ease, _easeOptions, _subscriptions, _updateSubscribers, updateSubscribers_fn;
var DraggableOptions = class {
  constructor({ ease, easeOptions } = {}) {
    __privateAdd(this, _updateSubscribers);
    __privateAdd(this, _ease, false);
    __privateAdd(this, _easeOptions, { duration: 0.1, ease: cubicOut });
    /**
     * Stores the subscribers.
     *
     * @type {(function(DraggableOptions): void)[]}
     */
    __privateAdd(this, _subscriptions, []);
    Object.defineProperty(this, "ease", {
      get: () => {
        return __privateGet(this, _ease);
      },
      set: (newEase) => {
        if (typeof newEase !== "boolean") {
          throw new TypeError(`'ease' is not a boolean.`);
        }
        __privateSet(this, _ease, newEase);
        __privateMethod(this, _updateSubscribers, updateSubscribers_fn).call(this);
      },
      enumerable: true
    });
    Object.defineProperty(this, "easeOptions", {
      get: () => {
        return __privateGet(this, _easeOptions);
      },
      set: (newEaseOptions) => {
        if (newEaseOptions === null || typeof newEaseOptions !== "object") {
          throw new TypeError(`'easeOptions' is not an object.`);
        }
        if (newEaseOptions.duration !== void 0) {
          if (!Number.isFinite(newEaseOptions.duration)) {
            throw new TypeError(`'easeOptions.duration' is not a finite number.`);
          }
          if (newEaseOptions.duration < 0) {
            throw new Error(`'easeOptions.duration' is less than 0.`);
          }
          __privateGet(this, _easeOptions).duration = newEaseOptions.duration;
        }
        if (newEaseOptions.ease !== void 0) {
          if (typeof newEaseOptions.ease !== "function" && typeof newEaseOptions.ease !== "string") {
            throw new TypeError(`'easeOptions.ease' is not a function or string.`);
          }
          __privateGet(this, _easeOptions).ease = newEaseOptions.ease;
        }
        __privateMethod(this, _updateSubscribers, updateSubscribers_fn).call(this);
      },
      enumerable: true
    });
    if (ease !== void 0) {
      this.ease = ease;
    }
    if (easeOptions !== void 0) {
      this.easeOptions = easeOptions;
    }
  }
  /**
   * @returns {number} Get ease duration
   */
  get easeDuration() {
    return __privateGet(this, _easeOptions).duration;
  }
  /**
   * @returns {string|Function} Get easing function value.
   */
  get easeValue() {
    return __privateGet(this, _easeOptions).ease;
  }
  /**
   * @param {number}   duration - Set ease duration.
   */
  set easeDuration(duration) {
    if (!Number.isFinite(duration)) {
      throw new TypeError(`'duration' is not a finite number.`);
    }
    if (duration < 0) {
      throw new Error(`'duration' is less than 0.`);
    }
    __privateGet(this, _easeOptions).duration = duration;
    __privateMethod(this, _updateSubscribers, updateSubscribers_fn).call(this);
  }
  /**
   * @param {string|Function} value - Get easing function value.
   */
  set easeValue(value) {
    if (typeof value !== "function" && typeof value !== "string") {
      throw new TypeError(`'value' is not a function or string.`);
    }
    __privateGet(this, _easeOptions).ease = value;
    __privateMethod(this, _updateSubscribers, updateSubscribers_fn).call(this);
  }
  /**
   * Resets all options data to default values.
   */
  reset() {
    __privateSet(this, _ease, false);
    __privateSet(this, _easeOptions, { duration: 0.1, ease: cubicOut });
    __privateMethod(this, _updateSubscribers, updateSubscribers_fn).call(this);
  }
  /**
   * Resets easing options to default values.
   */
  resetEase() {
    __privateSet(this, _easeOptions, { duration: 0.1, ease: cubicOut });
    __privateMethod(this, _updateSubscribers, updateSubscribers_fn).call(this);
  }
  /**
   *
   * @param {function(DraggableOptions): void} handler - Callback function that is invoked on update / changes.
   *                                                 Receives the DraggableOptions object / instance.
   *
   * @returns {(function(): void)} Unsubscribe function.
   */
  subscribe(handler) {
    __privateGet(this, _subscriptions).push(handler);
    handler(this);
    return () => {
      const index = __privateGet(this, _subscriptions).findIndex((sub) => sub === handler);
      if (index >= 0) {
        __privateGet(this, _subscriptions).splice(index, 1);
      }
    };
  }
};
_ease = new WeakMap();
_easeOptions = new WeakMap();
_subscriptions = new WeakMap();
_updateSubscribers = new WeakSet();
updateSubscribers_fn = function() {
  const subscriptions = __privateGet(this, _subscriptions);
  if (subscriptions.length > 0) {
    for (let cntr = 0; cntr < subscriptions.length; cntr++) {
      subscriptions[cntr](this);
    }
  }
};
draggable.options = (options) => new DraggableOptions(options);
var s_POSITION_DATA = { left: 0, top: 0 };

export {
  alwaysBlur,
  resizeObserver,
  applyScrolltop,
  autoBlur,
  isFocused,
  keyforward,
  applyStyles,
  applyPosition,
  draggable
};
//# sourceMappingURL=chunk-3Q76N6IK.js.map
