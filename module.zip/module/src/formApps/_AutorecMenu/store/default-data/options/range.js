export function range() {
    return {
        contrast: 0,
        delay: 0,
        elevation: 1000,
        isReturning: false,
        isWait: false,
        onlyX: false,
        opacity: 1,
        playbackRate: 1,
        repeat: 1,
        repeatDelay: 250,
        saturate: 0,
        tint: false,
        tintColor: "#FFFFFF",
        zIndex: 1,
    }
}